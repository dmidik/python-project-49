### Hexlet tests and linter status:
[![Actions Status](https://github.com/dmidik/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/dmidik/python-project-49/actions)


<a href="https://codeclimate.com/github/dmidik/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/511705f35bb7d21c4550/maintainability" /></a>


asciinema:
brain-even:
https://asciinema.org/a/T9wH3hHKigviY9tytQmCU1OoC
brain-calc:
https://asciinema.org/a/Wts9O8jLT1QgcsjI7sD7Kl3XV